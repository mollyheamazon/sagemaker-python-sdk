import argparse
import json
import logging
import os
import pathlib
import sys
import tarfile
from typing import Any
from typing import Dict
from typing import List
from typing import Tuple

from constants import constants
from datasets import load_dataset
from sagemaker_jumpstart_prepack_script_utilities.prepack_inference import copy_inference_code
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_recall_fscore_support
from transformers import AutoModelForSequenceClassification
from transformers import AutoTokenizer
from transformers import Trainer
from transformers import TrainingArguments
from transformers import set_seed


root = logging.getLogger()
root.setLevel(logging.INFO)
handler = logging.StreamHandler(sys.stdout)
root.addHandler(handler)


def _parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-dir", type=str, default=os.environ.get("SM_MODEL_DIR"))
    parser.add_argument("--train", type=str, default=os.environ.get("SM_CHANNEL_TRAINING"))
    parser.add_argument("--hosts", type=list, default=json.loads(os.environ.get("SM_HOSTS")))
    parser.add_argument("--current-host", type=str, default=os.environ.get("SM_CURRENT_HOST"))
    parser.add_argument("--pretrained-model", type=str, default=os.environ.get("SM_CHANNEL_MODEL"))
    parser.add_argument("--epochs", type=int, default=constants.DEFAULT_EPOCHS)
    parser.add_argument("--batch-size", type=int, default=constants.DEFAULT_BATCH_SIZE)
    parser.add_argument("--adam-learning-rate", type=float, default=constants.DEFAULT_ADAM_LEARNING_RATE)
    parser.add_argument("--metric-for-best-model", type=str, default=constants.METRIC_FOR_BEST_MODEL)
    parser.add_argument("--logging-steps", type=int, default=constants.DEFAULT_LOGGING_STEPS)
    parser.add_argument("--reinitialize-top-layer", type=str, default=constants.DEFAULT_REINITIALIZE_TOP_LAYER)
    parser.add_argument("--train-only-top-layer", type=str, default=constants.DEFAULT_TRAIN_ONLY_TOP_LAYER)
    parser.add_argument("--seed", type=int, default=constants.DEFAULT_SEED)

    return parser.parse_known_args()


def _prepare_data(data_dir: str, tokenizer):
    """Return pytorch data train and test tuple.

    Args:
        data_dir: directory where the .csv data file is loaded.
        tokenizer: tokenizer from the huggingface library.

    Returns:
        Tuple: pytorch data objects
    """
    # load dataset from csv
    dataset = load_dataset(
        "csv",
        data_files=[os.path.join(data_dir, constants.INPUT_DATA_FILENAME)],
        column_names=[constants.LABELS, constants.SENTENCES1, constants.SENTENCES2],
    )[constants.TRAIN]

    # preprocess dataset
    preprocessed_dataset = dataset.map(
        lambda batch: tokenizer(
            *(batch[constants.SENTENCES1], batch[constants.SENTENCES2]),
            padding=True,
            max_length=constants.MAX_SEQ_LENGTH,
            truncation=True,
        )
    )
    # train_test_split dataset
    preprocessed_dataset = preprocessed_dataset.train_test_split(test_size=1 - constants.TRAIN_VAL_SPLIT)
    return preprocessed_dataset[constants.TRAIN], preprocessed_dataset[constants.TEST]


def reinit_top_layer(model: Any) -> None:
    """Randomly reinitalize the parameters of the top layer using the built-in transformer function."""

    if hasattr(model, "classifier"):
        model._init_weights(model.classifier)
    if hasattr(model, "sequence_summary"):
        model._init_weights(model.sequence_summary)


def _get_model_and_tokenizer(args) -> Tuple[AutoModelForSequenceClassification, AutoTokenizer]:
    """Extract model files and load model and tokenizer.

    Args:
        args: parser argument
    Returns:
        object: a tuple of tokenizer and model.
    """
    if not os.path.exists(constants.INPUT_MODEL_UNTARRED_PATH):
        os.mkdir(constants.INPUT_MODEL_UNTARRED_PATH)

    input_model_path = next(pathlib.Path(args.pretrained_model).glob(constants.TAR_GZ_PATTERN))
    # extract model files
    with tarfile.open(input_model_path, "r") as saved_model_tar:
        saved_model_tar.extractall(constants.INPUT_MODEL_UNTARRED_PATH)
    # load model and tokenizer
    model = AutoModelForSequenceClassification.from_pretrained(constants.INPUT_MODEL_UNTARRED_PATH)
    tokenizer = AutoTokenizer.from_pretrained(constants.INPUT_MODEL_UNTARRED_PATH)
    if args.reinitialize_top_layer == constants.TRUE:
        reinit_top_layer(model)
    return model, tokenizer


def get_top_layer_param_names(model: Any) -> List[str]:
    """Return the names of parameters of the top layer."""
    if hasattr(model, "classifier"):
        return ["classifier." + param_name for param_name, _ in model.classifier.named_parameters()]
    if hasattr(model, "sequence_summary"):
        return ["sequence_summary." + param_name for param_name, _ in model.sequence_summary.named_parameters()]


def set_requires_grad(model: Any, train_only_top_layer: bool) -> None:
    """Set the require_grad attribute for each parameter based on train_only_top_layer.

    Parameters in the last layer are always trainable (requires_grad = True).
    For rest of the parameters, requires_grad = not train_only_top_layer.
    """
    top_layer_param_names = get_top_layer_param_names(model)
    for param_name, param in model.named_parameters():
        if param_name not in top_layer_param_names:
            param.requires_grad = not train_only_top_layer
        else:
            param.requires_grad = True


def _compute_metrics(pred) -> dict:
    """Computes accuracy, precision, and recall."""
    labels = pred.label_ids
    preds = pred.predictions.argmax(-1)
    precision, recall, f1, _ = precision_recall_fscore_support(labels, preds, average="binary")
    acc = accuracy_score(labels, preds)
    return {"accuracy": acc, "f1": f1, "precision": precision, "recall": recall}


def save_model_info(input_model_untarred_path: str, model_dir: str) -> None:
    """Save model info to the output directory along with finetuned parameter set to True.

    Read the existing model_info file in input_model directory if exists, set finetuned parameter to True and saves
    it in the output model directory.
    Args:
        input_model_untarred_path: Input model is untarred into this directory.
        model_dir: Output model directory.
    """
    input_model_info_file_path = os.path.join(input_model_untarred_path, constants.MODEL_INFO_FILE_NAME)
    try:
        with open(input_model_info_file_path, "r") as f:
            model_info: Dict[str, Any] = json.load(f)
    except FileNotFoundError:
        logging.info(f"Info file not found at '{input_model_info_file_path}'.")
        model_info: Dict[str, Any] = {}
    except Exception as e:
        logging.error(f"Error parsing model_info file: {e}.")
        raise

    model_info[constants.FINETUNED] = True

    output_model_info_file_path = os.path.join(model_dir, constants.MODEL_INFO_FILE_NAME)
    with open(output_model_info_file_path, "w") as f:
        f.write(json.dumps(model_info))


def run_with_args(args):
    """Run training."""

    set_seed(args.seed)

    model, tokenizer = _get_model_and_tokenizer(args=args)
    set_requires_grad(model, args.train_only_top_layer == constants.TRUE)

    train_dataset, eval_dataset = _prepare_data(args.train, tokenizer)

    logging.info(f" loaded train_dataset sizes is: {len(train_dataset)}")
    logging.info(f" loaded eval_dataset sizes is: {len(eval_dataset)}")

    # define training args
    training_args = TrainingArguments(
        output_dir=constants.INPUT_MODEL_UNTARRED_PATH,
        save_total_limit=1,
        num_train_epochs=args.epochs,
        per_device_train_batch_size=args.batch_size,
        per_device_eval_batch_size=args.batch_size,
        evaluation_strategy="epoch",
        logging_dir=constants.INPUT_MODEL_UNTARRED_PATH,
        learning_rate=float(args.adam_learning_rate),
        load_best_model_at_end=True,
        metric_for_best_model=args.metric_for_best_model,
        disable_tqdm=True,
        logging_first_step=True,
        logging_steps=args.logging_steps,
    )

    # create Trainer instance
    trainer = Trainer(
        model=model,
        tokenizer=tokenizer,
        args=training_args,
        compute_metrics=_compute_metrics,
        train_dataset=train_dataset,
        eval_dataset=eval_dataset,
    )

    # it executes the training loop and saves the best model.
    trainer.train()

    # Saves the model to s3
    trainer.model.save_pretrained(args.model_dir)
    trainer.tokenizer.save_pretrained(args.model_dir)
    with open(os.path.join(args.model_dir, constants.LABELS_INFO), "w") as nf:
        nf.write(json.dumps({constants.LABELS: [0, 1]}))
    save_model_info(input_model_untarred_path=constants.INPUT_MODEL_UNTARRED_PATH, model_dir=args.model_dir)


if __name__ == "__main__":
    args, unknown = _parse_args()
    run_with_args(args)
    copy_inference_code(dst_path=args.model_dir)
