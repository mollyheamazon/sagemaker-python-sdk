import json
import logging
import os

import numpy as np
import torch
from constants import constants
from sagemaker_inference import encoder
from transformers import AutoModelForSequenceClassification
from transformers import AutoTokenizer


DEVICE = torch.device(constants.CUDA if torch.cuda.is_available() else constants.CPU)


def model_fn(model_dir):
    """Create our inference task as a delegate to the model.

    This runs only once per one worker
    Raises:
        ValueError if the model file cannot be found.
    """
    try:
        with open(os.path.join(model_dir, constants.LABELS_INFO_FILE_NAME), "r") as txtFile:
            labels = json.loads(txtFile.read())[constants.LABELS]
        tokenizer = AutoTokenizer.from_pretrained(model_dir)
        model = AutoModelForSequenceClassification.from_pretrained(model_dir).to(DEVICE).eval()
        return tokenizer, model, labels
    except Exception:
        logging.exception("Failed to load model from: {}".format(model_dir))
        raise


def transform_fn(tokenizer_model_and_labels, input_data, content_type, accept):
    """Make predictions against the model and return a serialized response.

    The function signature conforms to the SM contract

    Args:
        tokenizer_and_model: a tuple of tokenizer and model loaded into memory
        input_data (obj): the request data.
        content_type (str): the request content type.
        accept (str): accept header expected by the client.

    Returns:
        obj: the serialized prediction result or a tuple of the form
            (response_data, content_type)

    """
    if content_type == constants.REQUEST_CONTENT_TYPE:
        sentence1, sentence2 = json.loads(input_data.decode(constants.STR_DECODE_CODE))
        try:
            tokenized_input = tokenizer_model_and_labels[0].encode_plus(sentence1, sentence2, return_tensors="pt")
            predictions = tokenizer_model_and_labels[1](**tokenized_input.to(DEVICE))[0]
            # np.argmax works on np arrays. Thus, we transfer the output from tensor on cuda to a numpy array on cpu.
            probabilities = predictions[0].cpu().detach().numpy()
            output = {constants.PROBABILITIES: probabilities}
            if accept.endswith(constants.VERBOSE_EXTENSION):
                output[constants.LABELS] = tokenizer_model_and_labels[2]
                predicted_label_idx = np.argmax(output[constants.PROBABILITIES])
                output[constants.PREDICTED_LABEL] = output[constants.LABELS][predicted_label_idx]
            accept = accept.strip(constants.VERBOSE_EXTENSION)
            return encoder.encode(output, accept)
        except Exception:
            logging.exception("Failed to do inference")
            raise
    raise ValueError('{{"error": "unsupported content type {}"}}'.format(content_type or "unknown"))
